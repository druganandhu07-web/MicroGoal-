const errormiddleware = (err, req, res, next) => {

  console.error(err.stack);

  res.status(500).json({
    message: err.message || "Something went wrong"
  });

};

module.exports = errormiddleware;