const express = require("express");
const router = express.Router();

const Goal = require("../Models/Goal");
const authMiddleware = require("../Middlewares/authMiddleware");


/* CREATE GOAL */

router.post("/goals", authMiddleware, async (req, res) => {

  try {

    const goal = new Goal({
      title: req.body.title,
      user: req.user
    });

    await goal.save();

    res.status(201).json(goal);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }

});


/* GET ALL USER GOALS */

router.get("/goals", authMiddleware, async (req, res) => {

  try {

    const goals = await Goal.find({ user: req.user });

    res.json(goals);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }

});


/* UPDATE GOAL */

router.put("/goals/:id", authMiddleware, async (req, res) => {

  try {

    const goal = await Goal.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    res.json(goal);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }

});


/* DELETE GOAL */

router.delete("/goals/:id", authMiddleware, async (req, res) => {

  try {

    await Goal.findByIdAndDelete(req.params.id);

    res.json({
      message: "Goal deleted"
    });

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }

});


module.exports = router;